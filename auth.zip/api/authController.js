const User = require("../api/userSchema");
const sha512 = require("crypto-js/sha512");
const crypto = require("crypto");

class authController {
  async register(req, res) {
    try {
      const { username, password, email } = req.body;
      const candidate = await User.findOne({ username });
      if (candidate) {
        return res.status(400).json({ message: "User already registered" });
      }
      const hashedPassword = sha512(password).toString();
      const user = new User({
        email: email,
        username:username,
        password:hashedPassword,
        uuid:crypto.randomUUID().toString().replace(/-/g, "")
      });
      await user.save();
      return res.status(200).json({ message: "User successfully registered" });
    } catch (error) {
      console.log(error);
      res.status(400).send(error);
    }
  }

  async login(req, res) {
    try {
      const { username, password } = req.body;
      const user = await User.findOne({ username });
      if (!user) {
        return res.status(400).json({ message: "User does not exist or invalid password" });
      }
      const validatePassword = sha512(password).toString() == user.password
      if (!validatePassword) {
        return res.status(400).json({ message: "User does not exist or invalid password" });
      }
      res.status(200).json({ message: "User login successful" });
    } catch (error) {
      console.log(error);
      res.status(400).send(error);
    }
  }
}

module.exports = new authController();
