const express = require("express");
const router = express.Router();
const clientController = require("./clientController");

router.get("/download", clientController.download);

module.exports = router;