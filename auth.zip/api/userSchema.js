const mongoose = require("mongoose");

const User = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    unique: true
  },
  username: {
    type: String,
    required: true,
    unique: true,
    maxlength: 16 
  },
  uuid: {
    type: String,
    maxlength: 32,
    required: true
  },
  password: {
    type: String,
    required: true,
    maxlength: 255
  },
  accessToken: {
    type: String,
    maxlength: 32,
    default: ""
  },
  serverID: {
    type: String,
    maxlength: 42,
    default: ""
  },
  isBanned: {
    type: Number,
    default: 0
  },
  date: {
    type: Date,
    default: Date.now()
  }
});

module.exports = mongoose.model("User", User);
