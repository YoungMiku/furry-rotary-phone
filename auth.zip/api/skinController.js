const User = require("../api/userSchema");
const fs = require("fs");
const md5 = require("md5-file")
const sha512 = require("crypto-js/sha512");
const md5Text = require("crypto-js/md5")

async function getSkinUrl(username, type) {
  const texture = `./textures/${type}/${username.toLowerCase()}.png`;
  if (fs.existsSync(texture)) {
      const skin = `./skins/${md5.sync(texture).toString()}.png`;
      fs.copyFile(texture, skin, (err) => {if (err) throw err;});
      return `http://localhost:9050/skins/${md5.sync(texture).toString()}.png`;
  } else return false;
}

async function getProfile (uuid, username) {
  if(await getSkinUrl(username, "skin")){textures = {SKIN: { url: await getSkinUrl(username, "skin") },}}
  if(await getSkinUrl(username, "cape")){textures = { 
  SKIN: { url: await getSkinUrl(username, "skin") },
  CAPE: { url: await getSkinUrl(username, "cape") },
}}
  const property = {
    timestamp: Date.now(),
    profileId: uuid,
    profileName: username,
    textures: textures,
  };
  const result = {
    id: uuid,
    name: username,
    properties: [
      {
        name: "textures",
        value: Buffer.from(JSON.stringify(property)).toString("base64"),
        signature: "",
      },
    ],
  };
  return result
}

class skinController {
  async profile(req, res) {
    try {
      const { uuid } = req.query;
      const user = await User.findOne({ "uuid": uuid});
      if (!user) {
        console.log(`\x1b[33m${new Date(Date.now()).toLocaleString()} LOG:\x1b[0m \x1b[41merror: "Invalid uuid or user does not exist": ${uuid}\x1b[0m`);
        return res.status(400).json({ message: "User does not exist" });
      }  
      const result = await getProfile(uuid,user.username)
      console.log(`\x1b[33m${new Date(Date.now()).toLocaleString()} LOG:\x1b[0m \x1b[42msuccess: "Profile found": ${user.username}\x1b[0m`);
      return res.status(200).json(result);
    } catch (error) {
      return res.status(400).send(error);
    }
  }

  async join(req, res) {
    try{
      const {serverId , selectedProfile , accessToken } = req.body;
      const user = await User.findOne({ "uuid":selectedProfile });
      if (!user) {
        console.log(`\x1b[33m${new Date(Date.now()).toLocaleString()} LOG:\x1b[0m \x1b[41merror: "Invalid uuid or user does not exist": ${selectedProfile}\x1b[0m`);
        return res.status(400).json({ message: "User does not exist" });
      }
      const join = accessToken == user.accessToken;
      if (!join) {
        console.log(`\x1b[33m${new Date(Date.now()).toLocaleString()} LOG:\x1b[0m \x1b[41merror: "Invalid token"\x1b[0m`);
        return res.status(400).json({ message: "token invalid" });
      }
      user.serverID = serverId;
      await user.save();
      console.log(`\x1b[33m${new Date(Date.now()).toLocaleString()} LOG:\x1b[0m \x1b[42msuccess: "User joined": ${user.username}\x1b[0m`);
      return res.end(200)
    }
    catch (error) {
      return res.status(400).send(error);
    }
  }

  async hasJoined(req, res) {
    try {
      const { serverId, username}  = req.query;
      const user = await User.findOne({ username });
      if (!user) {
        console.log(`\x1b[33m${new Date(Date.now()).toLocaleString()} LOG:\x1b[0m \x1b[41merror: "Invalid username or user does not exist": ${username}\x1b[0m`);
        return res.status(400).json({ message: "User does not exist " });
      }
      const hasJoined = serverId == user.serverID
      if (!hasJoined) {
        console.log(`\x1b[33m${new Date(Date.now()).toLocaleString()} LOG:\x1b[0m \x1b[41merror: "User serverID incorrect"\x1b[0m`);
        return res.status(400).json({ message: "User serverID incorrect" });
      }
      const result = await getProfile(user.uuid,user.username)
      console.log(`\x1b[33m${new Date(Date.now()).toLocaleString()} LOG:\x1b[0m \x1b[42msuccess: "User hasJoined": ${user.username}\x1b[0m`);
      return res.status(200).json(result);
    } catch (error) {
      console.log(error);
      return res.status(400).send(error);
    }
  }

  async launcher(req, res) {
    function genAcessToken() {
      const raw =
      (Math.floor(Math.random() * (2147483647 - 1000000000)) + 1000000000).toString() +
      (Math.floor(Math.random() * (2147483647 - 1000000000)) + 1000000000).toString() +
      (Math.floor(Math.random() * (9 - 0)) + 0).toString();
      const result = md5Text(raw);
      return result.toString();
    }
    const { username, password } = req.query;
    const user = await User.findOne({ username });
    if (!user) {
      return res.status(400).json({ message: "User does not exist or invalid request" });
    }
    const validatePassword = sha512(password).toString() == user.password
    if (!validatePassword) {
      return res.status(400).json({ message: "User does not exist or invalid password" });
    }
    user.accessToken = genAcessToken();
    await user.save();
    return res.status(200).json({accessToken: user.accessToken,uuid: user.uuid});
  }
}

module.exports = new skinController();
