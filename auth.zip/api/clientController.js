const User = require("../api/userSchema");
const md5File = require("md5-file");
const fs = require("fs");
const path = require("path");
const md5 = require("crypto-js/md5");

function formatBytes(a, b = 2, k = 1024) {
  with (Math) {
    let d = floor(log(a) / log(k));
    return 0 == a
      ? "0 Bytes"
      : parseFloat((a / pow(k, d)).toFixed(max(0, b))) +
          " " +
          ["Bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"][d];
  }
}

class clientController {
  async download(req, res) {
    try {
      const { filename } = req.query;
      const filePath = `./client/${filename}.zip`;
      //const reader = fs.createReadStream(filePath);
      res
        .set({
          "Content-Type": "application/zip",
          "Content-Length": fs.statSync(filePath).size,
        })
        .download(filePath);
      console.log(
        `Client.zip size: ${formatBytes(fs.statSync(filePath).size)} ( ${
          fs.statSync(filePath).size
        } Bytes ) \nMD5 checksum: ${md5File.sync(filePath)}`
      );
    } catch (err) {
      console.log(err);
    }
  }
}

module.exports = new clientController();
