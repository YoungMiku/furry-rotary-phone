const express = require("express");
const router = express.Router();
const skinController = require("./skinController");

router.post("/join", skinController.join);

router.get("/profile", skinController.profile);

router.get("/hasJoined", skinController.hasJoined);

router.get("/launcher", skinController.launcher);

module.exports = router;
