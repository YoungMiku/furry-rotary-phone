require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const app = express();

app.use(cors());
app.use(express.json());

//#region Api routes
const skinRoute = require("./api/skin");
app.use("/api/v1", skinRoute);

const authRoute = require("./api/auth");
app.use("/api/v1/auth", authRoute);
//#endregion

//#region Static route
const clientRoute = require("./api/client");
app.use("/client", clientRoute);
app.use("/skins", express.static("./skins"));
app.use("/cloacks", express.static("./cloacks"));
app.use("/textures", express.static("./textures"));

//#endregion

//#region MainPage route
app.get("/", (req, res) => {
  res.send("MainPage");
});
//#endregion

//#region Database connection
mongoose
  .connect(process.env.DB_URL, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log(`\x1b[33m${new Date(Date.now()).toLocaleString()} LOG:\x1b[0m \x1b[42msuccess: "Successfully connected to database"\x1b[0m`);
  })
  .catch((err) => {
    console.log(`\x1b[33m${new Date(Date.now()).toLocaleString()} LOG:\x1b[0m \x1b[41merror: "Connection error": ${err}\x1b[0m`);
  });
//#endregion

//#region ServerListen
const server = app.listen(process.env.SERVER_PORT || 3000, () => {
  console.log(`\x1b[33m${new Date(Date.now()).toLocaleString()} LOG:\x1b[0m \x1b[42msuccess: "Server started at port": ${server.address().port}\x1b[0m`);
});
//#endregion
