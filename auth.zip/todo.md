(A) Serve game files {cm:2022-04-10}
(A) Check files integrity (md5)
(B) Auth launcher
(B) s